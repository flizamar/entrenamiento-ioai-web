# 05 · Comparar modelos y geometrías

Comparar modelos con el mismo protocolo y contrastar k-means, dbscan, jerárquico y espectral sobre dos geometrías.

- Ideas que aparecen: laboratorios 02 y 04; distancia entre vectores.
- Archivos: `inicio.ipynb`, `solucion.ipynb` y la carpeta `datos/` completa.
- Entorno: Python del entorno de estudio con NumPy, pandas, scikit-learn
  y Jupyter. Sigue `ruta/Laboratorios guiados.md` en el repositorio o su
  página del sitio. No hay instalaciones, descargas ni accesos a cuentas
  dentro del notebook; basta CPU.
- Abre Jupyter desde esta carpeta y ejecuta **Reiniciar kernel y ejecutar todo**.
  Conserva los CSV dentro de `datos/`. El inicio ya corre y produce un
  baseline que puedes modificar y comparar con la solución.
- Métrica: accuracy supervisada; ARI educativo en clustering, fracción de ruido y número de grupos.
- Partición: clasificación: 160 train/80 validación/80 transferencia; clustering: dos conjuntos independientes de 160 puntos.

## Una idea para explorar

¿Qué forma de frontera aprende cada clasificador? Compara medias lunas y nubes compactas: ¿qué noción de grupo encaja en cada dibujo? Cambia eps de DBSCAN y observa cuándo aparecen ruido, uniones o fragmentos; no hay un ganador universal.

El inicio corre con un baseline. Modifica las celdas de experimentación,
observa figuras y consulta la solución separada cuando te sea útil. No hay
pasos que firmar ni formulario de seguimiento. `resultado.json` se escribe
automáticamente para verificar el material; no es una tarea administrativa.
Las aserciones de la solución comprueban su ejemplo, no acreditan dominio
del alumno ni equivalen a un puntaje oficial.

## Procedencia

Datos sintéticos educativos creados por `herramientas/generar_laboratorios.py`
con semillas fijas. No son datos de personas ni tareas oficiales. Los CSV
y los notebooks de esta carpeta se dedican a **CC0-1.0**; ver `LICENCIA.md`.
El manifiesto superior registra SHA-256 de los datos. Las soluciones
versionadas no contienen salidas; la verificación ejecuta copias temporales.
