# 02 · Del CSV a una entrega válida

Entrenar un clasificador, medirlo y exportar predicciones conservando los identificadores y su orden.

- Ideas que aparecen: laboratorios 00 y 01; diferencia entre ejemplo y etiqueta.
- Archivos: `inicio.ipynb`, `solucion.ipynb` y la carpeta `datos/` completa.
- Entorno: Python del entorno de estudio con NumPy, pandas, scikit-learn
  y Jupyter. Sigue `ruta/Laboratorios guiados.md` en el repositorio o su
  página del sitio. No hay instalaciones, descargas ni accesos a cuentas
  dentro del notebook; basta CPU.
- Abre Jupyter desde esta carpeta y ejecuta **Reiniciar kernel y ejecutar todo**.
  Conserva los CSV dentro de `datos/`. El inicio ya corre y produce un
  baseline que puedes modificar y comparar con la solución.
- Métrica: accuracy (mayor es mejor).
- Partición: 180 entrenamiento y 60 validación fijos; 60 transferencia con identificadores desordenados.

## Una idea para explorar

¿Dónde se equivoca la frontera? Mueve un punto, cambia la escala de una feature o baraja las filas de entrada conservando sus IDs. Distingue un cambio del modelo de un error al construir la entrega.

El inicio corre con un baseline. Modifica las celdas de experimentación,
observa figuras y consulta la solución separada cuando te sea útil. No hay
pasos que firmar ni formulario de seguimiento. `resultado.json` se escribe
automáticamente para verificar el material; no es una tarea administrativa.
Las aserciones de la solución comprueban su ejemplo, no acreditan dominio
del alumno ni equivalen a un puntaje oficial.

## Procedencia

Datos sintéticos educativos creados por `herramientas/generar_laboratorios.py`
con semillas fijas. No son datos de personas ni tareas oficiales. Los CSV
y los notebooks de esta carpeta se dedican a **CC0-1.0**; ver `LICENCIA.md`.
El manifiesto superior registra SHA-256 de los datos. Las soluciones
versionadas no contienen salidas; la verificación ejecuta copias temporales.
