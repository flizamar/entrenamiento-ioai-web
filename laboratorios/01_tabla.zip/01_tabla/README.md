# 01 · Una tabla con números, categorías y ausencias

Inspeccionar una tabla y ajustar imputación y one-hot solo con entrenamiento, aceptando una categoría nueva.

- Ideas que aparecen: laboratorio 00 y lectura de archivos (cápsula 2).
- Archivos: `inicio.ipynb`, `solucion.ipynb` y la carpeta `datos/` completa.
- Entorno: Python del entorno de estudio con NumPy, pandas, scikit-learn
  y Jupyter. Sigue `ruta/Laboratorios guiados.md` en el repositorio o su
  página del sitio. No hay instalaciones, descargas ni accesos a cuentas
  dentro del notebook; basta CPU.
- Abre Jupyter desde esta carpeta y ejecuta **Reiniciar kernel y ejecutar todo**.
  Conserva los CSV dentro de `datos/`. El inicio ya corre y produce un
  baseline que puedes modificar y comparar con la solución.
- Métrica: accuracy (mayor es mejor).
- Partición: columna particion fija: 160 entrenamiento, 40 validación, 40 transferencia.

## Una idea para explorar

¿Qué aprende cada transformación y de qué filas? Quita una feature o cambia una categoría por un nombre nuevo. ¿Falla el programa, cambia la predicción o conserva exactamente la misma? Usa el dibujo para buscar ejemplos donde una sola variable no basta.

El inicio corre con un baseline. Modifica las celdas de experimentación,
observa figuras y consulta la solución separada cuando te sea útil. No hay
pasos que firmar ni formulario de seguimiento. `resultado.json` se escribe
automáticamente para verificar el material; no es una tarea administrativa.
Las aserciones de la solución comprueban su ejemplo, no acreditan dominio
del alumno ni equivalen a un puntaje oficial.

## Procedencia

Datos sintéticos educativos creados por `herramientas/generar_laboratorios.py`
con semillas fijas. No son datos de personas ni tareas oficiales. Los CSV
y los notebooks de esta carpeta se dedican a **CC0-1.0**; ver `LICENCIA.md`.
El manifiesto superior registra SHA-256 de los datos. Las soluciones
versionadas no contienen salidas; la verificación ejecuta copias temporales.
