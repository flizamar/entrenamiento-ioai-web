# 07 · Una cabeza nueva y un adaptador que aprende

Un BERT diminuto local permite observar qué cambia al entrenar LoRA y la cabeza, sin descargar modelos.

Prepara el entorno con `requirements-avanzado.txt` y
`requirements-estudio.txt` juntos: `python -m pip install -r requirements-avanzado.txt`.
Abre `inicio.ipynb` desde Jupyter en ese entorno y ejecuta sus celdas.
Empieza por observar el baseline, cambia una variable y vuelve a mirar
las curvas. `solucion.ipynb` conserva un experimento de referencia en
otro archivo. Ambos producen `resultado.json` sin cambiar los datos.

Entrada sugerida: módulos 12–14; atención, clasificación y congelación de parámetros. Tiempo orientativo: 60–90 minutos de exploración, sin límite de juez.
No hay cuestionarios ni un puntaje de dominio; las figuras y variantes
están para explorar el mecanismo. Las aserciones de la referencia
protegen su funcionamiento como parte de la verificación del repositorio.

**Métrica:** accuracy sobre secuencias de tokens sintéticos (mayor es mejor). **Partición:** 96 train, 48 validación y 48 transferencia; generador torch con semilla 41, transferencia duplica longitud de 5 a 10.

Datos sintéticos generados dentro de las celdas, con semilla fija,
dedicados a CC0-1.0 junto al notebook. No usa datos personales, cuentas,
descargas ni GPU. Instala el entorno de estudio antes de abrirlo; los
paquetes se preparan fuera de la ejecución. Las salidas no se versionan.

El encoder comienza al azar: este experimento comprueba el mecanismo de LoRA, no la calidad de un modelo de lenguaje preentrenado.
