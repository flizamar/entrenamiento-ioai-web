# 04 · La pregunta que decide el split

Comparar filas nuevas de grupos conocidos con grupos completamente nuevos sin confundir las dos preguntas.

- Ideas que aparecen: laboratorio 02; independencia y muestreo (cápsula 4).
- Archivos: `inicio.ipynb`, `solucion.ipynb` y la carpeta `datos/` completa.
- Entorno: Python del entorno de estudio con NumPy, pandas, scikit-learn
  y Jupyter. Sigue `ruta/Laboratorios guiados.md` en el repositorio o su
  página del sitio. No hay instalaciones, descargas ni accesos a cuentas
  dentro del notebook; basta CPU.
- Abre Jupyter desde esta carpeta y ejecuta **Reiniciar kernel y ejecutar todo**.
  Conserva los CSV dentro de `datos/`. El inicio ya corre y produce un
  baseline que puedes modificar y comparar con la solución.
- Métrica: accuracy y solapamiento de grupos; una accuracy menor no es un fallo si cambia la pregunta.
- Partición: datos de desarrollo: 24 grupos × 8 filas; transferencia: otros 12 grupos × 8 filas.

## Una idea para explorar

¿Qué futuro imagina cada split? Observa puntos casi repetidos de un grupo y busca dónde aparecen sus vecinos. ¿Cambiaría tu evaluación si el siguiente ejemplo perteneciera a un grupo conocido, a uno nuevo o al mes siguiente?

El inicio corre con un baseline. Modifica las celdas de experimentación,
observa figuras y consulta la solución separada cuando te sea útil. No hay
pasos que firmar ni formulario de seguimiento. `resultado.json` se escribe
automáticamente para verificar el material; no es una tarea administrativa.
Las aserciones de la solución comprueban su ejemplo, no acreditan dominio
del alumno ni equivalen a un puntaje oficial.

## Procedencia

Datos sintéticos educativos creados por `herramientas/generar_laboratorios.py`
con semillas fijas. No son datos de personas ni tareas oficiales. Los CSV
y los notebooks de esta carpeta se dedican a **CC0-1.0**; ver `LICENCIA.md`.
El manifiesto superior registra SHA-256 de los datos. Las soluciones
versionadas no contienen salidas; la verificación ejecuta copias temporales.
