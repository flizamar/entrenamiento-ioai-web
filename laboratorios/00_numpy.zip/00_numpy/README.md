# 00 · Formas y normalización con NumPy

Normalizar por columna, preservar formas y resolver una columna constante sin dividir por cero.

- Ideas que aparecen: funciones, listas, media y desviación (cápsulas 1 y 4).
- Archivos: `inicio.ipynb`, `solucion.ipynb` y la carpeta `datos/` completa.
- Entorno: Python del entorno de estudio con NumPy, pandas, scikit-learn
  y Jupyter. Sigue `ruta/Laboratorios guiados.md` en el repositorio o su
  página del sitio. No hay instalaciones, descargas ni accesos a cuentas
  dentro del notebook; basta CPU.
- Abre Jupyter desde esta carpeta y ejecuta **Reiniciar kernel y ejecutar todo**.
  Conserva los CSV dentro de `datos/`. El inicio ya corre y produce un
  baseline que puedes modificar y comparar con la solución.
- Métrica: error absoluto máximo frente al baseline correcto (menor es mejor).
- Partición: sin entrenamiento; desarrollo y transferencia son matrices separadas.

## Una idea para explorar

¿Qué información conserva normalizar una columna y cuál cambia? Prueba una columna constante, una sola fila o unidades cien veces mayores. Predice el resultado antes de ejecutarlo. Compara los tiempos por curiosidad; el factor depende del equipo.

El inicio corre con un baseline. Modifica las celdas de experimentación,
observa figuras y consulta la solución separada cuando te sea útil. No hay
pasos que firmar ni formulario de seguimiento. `resultado.json` se escribe
automáticamente para verificar el material; no es una tarea administrativa.
Las aserciones de la solución comprueban su ejemplo, no acreditan dominio
del alumno ni equivalen a un puntaje oficial.

## Procedencia

Datos sintéticos educativos creados por `herramientas/generar_laboratorios.py`
con semillas fijas. No son datos de personas ni tareas oficiales. Los CSV
y los notebooks de esta carpeta se dedican a **CC0-1.0**; ver `LICENCIA.md`.
El manifiesto superior registra SHA-256 de los datos. Las soluciones
versionadas no contienen salidas; la verificación ejecuta copias temporales.
