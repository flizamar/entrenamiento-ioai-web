# Licencia de los laboratorios iniciales

Los datos CSV sintéticos, notebooks y guías de `00_numpy`, `01_tabla`,
`02_clasificacion`, `03_metricas`, `04_validacion` y `05_modelos` se dedican al
dominio público mediante **CC0-1.0**. Puedes usarlos, modificarlos y redistribuirlos.

Texto legal: https://creativecommons.org/publicdomain/zero/1.0/legalcode.es

Los datos se generan con funciones matemáticas y semillas fijas de
`herramientas/generar_laboratorios.py`. No contienen registros de personas ni
fragmentos de datasets oficiales. Las dependencias conservan sus propias licencias.
