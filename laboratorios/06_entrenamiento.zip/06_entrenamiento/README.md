# 06 · Qué aprende un bucle de entrenamiento

Curvas de entrenamiento, checkpoints, microbatches y etiquetas que viajan con sus features.

Prepara el entorno con `requirements-avanzado.txt` y
`requirements-estudio.txt` juntos: `python -m pip install -r requirements-avanzado.txt`.
Abre `inicio.ipynb` desde Jupyter en ese entorno y ejecuta sus celdas.
Empieza por observar el baseline, cambia una variable y vuelve a mirar
las curvas. `solucion.ipynb` conserva un experimento de referencia en
otro archivo. Ambos producen `resultado.json` sin cambiar los datos.

Entrada sugerida: módulos 09–12 y 15; tensores, gradientes y pérdida media. Tiempo orientativo: 60–90 minutos de exploración, sin límite de juez.
No hay cuestionarios ni un puntaje de dominio; las figuras y variantes
están para explorar el mecanismo. Las aserciones de la referencia
protegen su funcionamiento como parte de la verificación del repositorio.

**Métrica:** MAE en regresión sintética (menor es mejor). **Partición:** 80 train, 40 validación, 40 transferencia generados con semilla 23; transferencia amplía el intervalo de x.

Datos sintéticos generados dentro de las celdas, con semilla fija,
dedicados a CC0-1.0 junto al notebook. No usa datos personales, cuentas,
descargas ni GPU. Instala el entorno de estudio antes de abrirlo; los
paquetes se preparan fuera de la ejecución. Las salidas no se versionan.
