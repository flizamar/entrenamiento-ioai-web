# Siguiente token, audio y representaciones

Abre `inicio.ipynb` en esta carpeta. El cuaderno está completo: explora las figuras,
cambia las condiciones y contrasta tu explicación. `solucion.ipynb` muestra otra
configuración y comentarios sobre lo observado; no es una pauta para rellenar.

Datos sintéticos generados localmente, CC0-1.0. Solo CPU; sin descargas ni cuentas.
Dependencias: NumPy, SciPy, scikit-learn, PyTorch y Matplotlib del entorno del curso.
Las ejecuciones escriben `resultado.json` como resumen interno de verificación.

Métrica del resumen: Perplejidad de siguiente token, menor es mejor.
Comparación: corpus train fijo; frases nuevas de validación; frases con papeles invertidos de transferencia.
Los resultados no equivalen a un entrenamiento oficial IOAI ni a modelos preentrenados.
