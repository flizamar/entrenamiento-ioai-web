# 03 · Ranking, ROC/AUC y umbral

Distinguir calidad del ranking de una decisión por umbral y elegir ese umbral sin mirar test.

- Ideas que aparecen: laboratorio 02; proporción y probabilidad (cápsula 5).
- Archivos: `inicio.ipynb`, `solucion.ipynb` y la carpeta `datos/` completa.
- Entorno: Python del entorno de estudio con NumPy, pandas, scikit-learn
  y Jupyter. Sigue `ruta/Laboratorios guiados.md` en el repositorio o su
  página del sitio. No hay instalaciones, descargas ni accesos a cuentas
  dentro del notebook; basta CPU.
- Abre Jupyter desde esta carpeta y ejecuta **Reiniciar kernel y ejecutar todo**.
  Conserva los CSV dentro de `datos/`. El inicio ya corre y produce un
  baseline que puedes modificar y comparar con la solución.
- Métrica: F1 binario de clase positiva 1; ROC-AUC como diagnóstico de ranking (mayor es mejor).
- Partición: 60 pares etiqueta-score de validación; 50 de transferencia separados; modelo ya congelado.

## Una idea para explorar

¿Puedes mejorar F1 sin cambiar una sola posición del ranking? Mira cómo se mueve el punto de operación al cambiar el umbral. ¿Por qué un ranking muy bueno puede generar muchas falsas alarmas cuando hay pocos positivos?

El inicio corre con un baseline. Modifica las celdas de experimentación,
observa figuras y consulta la solución separada cuando te sea útil. No hay
pasos que firmar ni formulario de seguimiento. `resultado.json` se escribe
automáticamente para verificar el material; no es una tarea administrativa.
Las aserciones de la solución comprueban su ejemplo, no acreditan dominio
del alumno ni equivalen a un puntaje oficial.

## Procedencia

Datos sintéticos educativos creados por `herramientas/generar_laboratorios.py`
con semillas fijas. No son datos de personas ni tareas oficiales. Los CSV
y los notebooks de esta carpeta se dedican a **CC0-1.0**; ver `LICENCIA.md`.
El manifiesto superior registra SHA-256 de los datos. Las soluciones
versionadas no contienen salidas; la verificación ejecuta copias temporales.
